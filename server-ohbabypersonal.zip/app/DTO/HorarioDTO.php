<?php

namespace App\DTO;

class HorarioDTO {
    public int $id;
    public string $descripcion;
    public array $horarioDetalles;
}
