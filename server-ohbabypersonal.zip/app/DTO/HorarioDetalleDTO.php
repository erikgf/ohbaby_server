<?php

namespace App\DTO;

class HorarioDetalleDTO {
    public int $id;
    public string $hora_inicio;
    public string $hora_fin;
    public string $dias;
    public int $id_horario;
}
