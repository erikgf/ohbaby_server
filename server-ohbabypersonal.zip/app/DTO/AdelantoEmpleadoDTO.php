<?php

namespace App\DTO;

class AdelantoEmpleadoDTO {
    public int $id;
    public int $id_empleado_contrato;
    public string $fecha;
    public string $importe;
}
