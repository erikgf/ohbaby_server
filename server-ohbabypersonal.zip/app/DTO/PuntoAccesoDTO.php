<?php

namespace App\DTO;

class PuntoAccesoDTO {
    public int $id;
    public string $descripcion;
}
